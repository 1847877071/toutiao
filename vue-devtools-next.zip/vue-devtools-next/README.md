# vue-devtools

![screenshot](./media/screenshot-shadow.png)

[Documentation](https://devtools.vuejs.org/)

### License

[MIT](http://opensource.org/licenses/MIT)

## Sponsors

[💚️ Become a Sponsor](https://github.com/sponsors/Akryum)

[![sponsors logos](https://guillaume-chau.info/sponsors.png)](https://guillaume-chau.info/sponsors)
