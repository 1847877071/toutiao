<template>
  Page 2
</template>
