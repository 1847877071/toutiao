export const HOOK_SETUP = 'devtools-plugin:setup'
