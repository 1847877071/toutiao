<template>
  <div>
    <p>Hello from route 1</p>
  </div>
</template>

<script>
export default {

}
</script>
